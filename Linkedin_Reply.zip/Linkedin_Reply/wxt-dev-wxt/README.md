# WXT + React

This template should help get you started developing with React in WXT.
