import React from 'react';

interface AIIconProps {
  onClick: () => void;
}

const AIIcon: React.FC<AIIconProps> = ({ onClick }) => {
  return (
    <div className="absolute bottom-2 right-2">
      <button onClick={onClick}>
        <img src="/public/icon.svg" alt="AI Icon" className="h-8 w-8 cursor-pointer" />
      </button>
    </div>
  );
};

export default AIIcon;
