import React, { useState } from 'react';

interface ModalProps {
  onClose: () => void;
  onGenerate: () => void;
  onInsert: () => void;
  message: string;
}

const Modal: React.FC<ModalProps> = ({ onClose, onGenerate, onInsert, message }) => {
  const [input, setInput] = useState('');

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
      <div className="bg-white p-6 rounded shadow-lg relative w-1/3">
        <button className="absolute top-2 right-2 text-gray-600" onClick={onClose}>X</button>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          className="w-full p-2 border rounded mb-4"
          placeholder="Type your command..."
        />
        <button 
          className="bg-blue-500 text-white px-4 py-2 rounded mr-2"
          onClick={onGenerate}
        >
          Generate
        </button>
        <button 
          className="bg-green-500 text-white px-4 py-2 rounded"
          onClick={onInsert}
        >
          Insert
        </button>
        <p className="mt-4 text-gray-700">{message}</p>
      </div>
    </div>
  );
};

export default Modal;
