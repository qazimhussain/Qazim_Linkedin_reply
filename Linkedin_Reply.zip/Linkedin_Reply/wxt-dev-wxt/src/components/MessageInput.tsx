import React from 'react';

interface MessageInputProps {
  onFocus: () => void;
}

const MessageInput: React.FC<MessageInputProps> = ({ onFocus }) => {
  return (
    <textarea
      className="border p-2 w-full"
      placeholder="Type your message here..."
      onFocus={onFocus}
    />
  );
};

export default MessageInput;
