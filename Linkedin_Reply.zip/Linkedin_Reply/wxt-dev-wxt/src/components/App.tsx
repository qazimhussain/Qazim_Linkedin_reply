import React, { useState } from 'react';
import MessageInput from './MessageInput';
import AIIcon from './AIIcon';
import Modal from './Modal';

const App = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [message, setMessage] = useState('');

  const handleIconClick = () => {
    setIsModalOpen(true);
  };

  const handleOutsideClick = () => {
    setIsModalOpen(false);
  };

  const handleGenerate = () => {
    const generatedText = `Thank you for the opportunity! If you have any more questions or if there's anything else I can help you with, feel free to ask.`;
    setMessage(generatedText);
  };

  const handleInsert = () => {
    const inputElement = document.querySelector('textarea'); // Assuming LinkedIn message field is a <textarea>
    if (inputElement) {
      (inputElement as HTMLTextAreaElement).value = message;
      setIsModalOpen(false);
    }
  };

  return (
    <div>
      <MessageInput onFocus={handleIconClick} />
      {isModalOpen && (
        <Modal 
          onClose={handleOutsideClick}
          onGenerate={handleGenerate}
          onInsert={handleInsert}
          message={message}
        />
      )}
      {!isModalOpen && <AIIcon onClick={handleIconClick} />}
    </div>
  );
};

export default App;
