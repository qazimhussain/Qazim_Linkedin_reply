chrome.runtime.onInstalled.addListener(() => {
    console.log("LinkedIn Reply Assistant installed.");
  });
  
  // Listen for messages from content scripts
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "toggleIcon") {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        chrome.scripting.executeScript({
          target: { tabId: tabs[0].id },
          function: toggleIcon,
          args: [request.visible]
        });
      });
    }
  });
  
  function toggleIcon(visible: boolean) {
    const icon = document.getElementById("ai-icon");
    if (icon) {
      icon.style.display = visible ? "block" : "none";
    }
  }
  