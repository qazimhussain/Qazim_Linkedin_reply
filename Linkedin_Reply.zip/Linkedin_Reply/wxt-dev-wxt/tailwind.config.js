module.exports = {
    content: [
     "./public/index.html", // Adjust according to your project structure
    ],
    theme: {
      extend: {},
    },
    plugins: [],
  };
  