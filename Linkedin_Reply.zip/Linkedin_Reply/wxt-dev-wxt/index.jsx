import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import App from './src/components/App';
import './styles/tailwind.css';

const Index = () => {
  return (
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
};

// Render the extension popup or app
ReactDOM.render(<Index />, document.getElementById('root'));
